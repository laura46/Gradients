$(function(){
  var clipboard = new Clipboard('.clipboard');
  var title = [
    "Selenium",
    "pink flower",
    "orange fun",
    "digital water",
    "argon",
    "summer",
    "orange coral",
    "purpink",
    "dull",
    "broker hearts",
    "subu",
    "crimson tide",
    "alive",
    "relay",
    "meredian",
    "mello",
    "crystal clear",
    "sunkist",
    "html",
    "maldives",
    "celestial",
    "love and liberty",
    "CYFTLT",
    "honey dew",
    "roseanna",
    "easy med",
    "vice city",
    "ibiza sunset",
    "radar",
    "black rose",
    "cosmic fusion",
    "eds dunset gradient",
    "firewatch",
    "mauve",
    "dusk",
    "sweet morning",
    "tranquil",
    "deep space",
    "haikus",
    "purplin",
    "blush",
    "back to earth",
    "master card",
    "passion",
    "timber",
    "piglet",
    "flicker",
    "atals",
    "martini",
    "a lost memory",
    "blurry peach",
    "day tripper",
    "shrimpy",
    "bourbon",
    "clouds",
    "peach",
    "sea blitzz",
    "electric voilet",
    "juicy orange",
    "cherry",
    "sea weed",
    "boody mary",
    "intutive purple",
    "reds"
  ];

  var gradCode = [
    "@include linear-gradient(19deg,#3C3B3F,#605C3C)",
    "@include linear-gradient(19deg,#800080,#ffc0cb)",
    "@include linear-gradient(19deg,#fc4a1a,#f7b733)",
    "@include linear-gradient(19deg,#74ebd5,#ACB6E5)",
    "@include linear-gradient(19deg,#03001e,#7303c0,#ec38bc,#fdeff9)",
    "@include linear-gradient(19deg,#22c1c3,#fdbb2d)",
    "@include linear-gradient(19deg,#ff9966,#ff5e62)",
    "@include linear-gradient(19deg,#7F00FF,#E100FF)",
    "@include linear-gradient(19deg,#C9D6FF,#E2E2E2)",
    "@include linear-gradient(19deg,#d9a7c7,#fffcdc)",
    "@include linear-gradient(19deg,#0cebeb,#20e3b2,#29ffc6)",
    "@include linear-gradient(19deg,#642B73,#C6426E)",
    "@include linear-gradient(19deg,#CB356B,#BD3F32)",
    "@include linear-gradient(19deg,#3A1C71,#D76D77,#FFAF7B)",
    "@include linear-gradient(19deg,#283c86,#45a247)",
    "@include linear-gradient(19deg,#c0392b,#8e44ad)",
    "@include linear-gradient(19deg,#159957,#155799)",
    "@include linear-gradient(19deg,#F2994A,#F2C94C)",
    "@include linear-gradient(19deg,#E44D26,#F16529)",
    "@include linear-gradient(19deg,#B2FEFA,#0ED2F7)",
    "@include linear-gradient(19deg,#C33764,#1D2671)",
    "@include linear-gradient(19deg,#200122,#6f0000)",
    "@include linear-gradient(19deg,#4568DC,#B06AB3)",
    "@include linear-gradient(19deg,#B06AB3,#F8FFAE)",
    "@include linear-gradient(19deg,#FFAFBD,#ffc3a0)",
    "@include linear-gradient(19deg,#DCE35B,#45B649)",
    "@include linear-gradient(19deg,#3494E6,#EC6EAD)",
    "@include linear-gradient(19deg,#ee0979,#ff6a00)",
    "@include linear-gradient(19deg,#CF8BF3,#FDB99B)",
    "@include linear-gradient(19deg,#f4c4f3,#fc67fa)",
    "@include linear-gradient(19deg,#ff00cc,#333399)",
    "@include linear-gradient(19deg,#ff7e5f,#feb47b)",
    "@include linear-gradient(19deg,#cb2d3e,#ef473a)",
    "@include linear-gradient(19deg,#42275a,#734b6d)",
    "@include linear-gradient(19deg,#ffd89b,#19547b)",
    "@include linear-gradient(19deg,#FF5F6D,#FFC371)",
    "@include linear-gradient(19deg,#EECDA3,#EF629F)",
    "@include linear-gradient(19deg,#000000,#434343)",
    "@include linear-gradient(19deg,#fd746c,#ff9068)",
    "@include linear-gradient(19deg,#6a3093,#a044ff)",
    "@include linear-gradient(19deg,#B24592,#F15F79)",
    "@include linear-gradient(19deg,#00C9FF,#92FE9D)",
    "@include linear-gradient(19deg,#f46b45,#eea849)",
    "@include linear-gradient(19deg,#e53935,#e35d5b)",
    "@include linear-gradient(19deg,#fc00ff,#00dbde)",
    "@include linear-gradient(19deg,#ee9ca7,#ffdde1)",
    "@include linear-gradient(19deg,#ff0084,#33001b)",
    "@include linear-gradient(19deg,#FEAC5E,#C779D0,#4BC0C8)",
    "@include linear-gradient(19deg,#FDFC47,#24FE41)",
    "@include linear-gradient(19deg,#DE6262,#FFB88C)",
    "@include linear-gradient(19deg,#d53369,#cbad6d)",
    "@include linear-gradient(19deg,#f857a6,#ff5858)",
    "@include linear-gradient(19deg,#e43a15,#e65245)",
    "@include linear-gradient(19deg,#EC6F66,#F3A183)",
    "@include linear-gradient(19deg,#ECE9E6,#FFFFFF)",
    "@include linear-gradient(19deg,#ED4264,#FFEDBC)",
    "@include linear-gradient(19deg,#1CD8D2,#93EDC7)",
    "@include linear-gradient(19deg,#4776E6,#8E54E9)",
    "@include linear-gradient(19deg,#FF8008,#FFC837)",
    "@include linear-gradient(19deg,#EB3349,#F45C43)",
    "@include linear-gradient(19deg,#4CB8C4,#3CD3AD)",
    "@include linear-gradient(19deg,#FF512F,#DD2476)",
    "@include linear-gradient(19deg,#DA22FF,#9733EE)",
    "@include linear-gradient(19deg,#D31027,#EA384D)",
    "@include linear-gradient(19deg,#ec008c,#fc6767)"
  ];

    for(var j =1;j<=64;j++){
      $('.rows').append('<div class="boxc"><div class="grad-title"><span>'+title[j-1]+'</span></div><div class="box"><div class="copy-option clipboard" data-clipboard-text="'+gradCode[j-1]+'"><span>copy</span></div><div class="grad-border"></div><div class="grad grad-'+j+'"></div></div></div>');
    }
    var whiteTheme = false;
    $('.rect-box').click(function(){
      if(whiteTheme == false){
        $('.rect-box').css("background-color","#222222");
        $('body').css("background-color","#dddddd");
        whiteTheme = true;
      }else{
        $('.rect-box').css("background-color","white");
        $('body').css("background-color","#222222");
        whiteTheme = false;
      }
      $('.main-back').toggleClass('white-theme');
      $('span').toggleClass('black-text');
    });

  $('.box').each(function(){
    $(this).hover(function(){
      var grad = $(this).find('.grad');
      var copyOption = $(this).find('.copy-option');
        TweenMax.to(grad,0.4,{x: '-4%',y: '-3%'});
        copyOption.css("opacity","0.4");
    },function(){
      var grad = $(this).find('.grad');
      var copyOption = $(this).find('.copy-option');
        TweenMax.to(grad,0.4,{x: '0%',y: '0%'});
        copyOption.css("opacity","0");
    });
  });



  $('.box').each(function(index){
    $(this).click(function(){
      console.log("this has been copied "+ gradCode[index]);
      $('.copy-option').css("background-color","#f66");
      setTimeout(function(){$('.copy-option').css("background-color","#ddd");},300);
    });
  });


});
